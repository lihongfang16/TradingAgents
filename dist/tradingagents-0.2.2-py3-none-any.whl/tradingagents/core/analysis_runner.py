# TradingAgents/core/analysis_runner.py
"""
Non-interactive, fully configurable runner for TradingAgents analysis workflow.
Can be called from both Streamlit UI and FastAPI.
"""

from datetime import datetime
from typing import Any, Callable, Dict, List, Optional

from tradingagents.default_config import DEFAULT_CONFIG
from tradingagents.graph.trading_graph import TradingAgentsGraph


# Agent steps for progress tracking
AGENT_STEPS = [
    ("graph_setup", "🚀", "初始化分析图"),
    ("market_analyst", "📊", "市场分析师"),
    ("sentiment_analyst", "💭", "情绪分析师"),
    ("news_analyst", "📰", "新闻分析师"),
    ("fundamentals_analyst", "🏢", "基本面分析师"),
    ("research_manager", "🔍", "研究经理"),
    ("bull_researcher", "🐂", "看涨研究员"),
    ("bear_researcher", "🐻", "看跌研究员"),
    ("trader", "💼", "交易员"),
    ("risk_manager", "⚠️", "风控经理"),
    ("portfolio_manager", "👔", "投资组合经理"),
]


class AnalysisRunner:
    """
    Non-interactive runner for TradingAgents analysis workflow.
    
    Provides a clean interface for running trading agent analysis
    without interactive prompts, suitable for Streamlit UI and FastAPI.
    """

    NODE_TO_STEP = {
        "Market Analyst": "market_analyst",
        "Social Analyst": "sentiment_analyst",
        "News Analyst": "news_analyst",
        "Fundamentals Analyst": "fundamentals_analyst",
        "Research Manager": "research_manager",
        "Bull Researcher": "bull_researcher",
        "Bear Researcher": "bear_researcher",
        "Trader": "trader",
        "Portfolio Manager": "portfolio_manager",
    }
    RISK_NODES = {"Aggressive Analyst", "Conservative Analyst", "Neutral Analyst"}
    IGNORE_NODES = {
        "tools_market",
        "tools_social",
        "tools_news",
        "tools_fundamentals",
        "Msg Clear Market",
        "Msg Clear Social",
        "Msg Clear News",
        "Msg Clear Fundamentals",
    }

    def __init__(
        self,
        symbol: str,
        date: str,
        analysts: List[str],
        llm_model: str,
        llm_provider: str,
        initial_cash: float = 100000.0,
        max_iterations: int = 300,
        base_url: Optional[str] = None,
        api_key: Optional[str] = None,
        progress_callback: Optional[Callable[[Dict[str, Any]], None]] = None,
    ):
        """
        Initialize the AnalysisRunner.

        Args:
            symbol: Stock symbol/ticker to analyze
            date: Trade date in format 'YYYY-MM-DD'
            analysts: List of analyst types to include (e.g., ["market", "news", "fundamentals"])
            llm_model: LLM model name for reasoning
            llm_provider: LLM provider (e.g., "openai", "anthropic", "google")
            initial_cash: Initial cash for portfolio (default: 100000.0)
            max_iterations: Maximum recursion/debate iterations (default: 300)
            base_url: Optional base URL for API endpoint
            api_key: Optional API key for LLM provider
            progress_callback: Optional callback function for progress updates
        """
        self.symbol = symbol
        self.date = date
        self.analysts = analysts
        self.llm_model = llm_model
        self.llm_provider = llm_provider
        self.initial_cash = initial_cash
        self.max_iterations = max_iterations
        self.base_url = base_url
        self.api_key = api_key
        self.progress_callback = progress_callback
        
        # Build config from parameters
        self.config = self._build_config()
        
        # Graph instance (created lazily on run)
        self._graph: Optional[TradingAgentsGraph] = None
        
        # Progress tracking
        self._progress_pct = 0
        self._agents_progress: Dict[str, str] = {}
        self._current_agent = ""

    def _build_config(self) -> Dict[str, Any]:
        """Build configuration dictionary from instance parameters."""
        config = DEFAULT_CONFIG.copy()
        config["llm_provider"] = self.llm_provider
        config["deep_think_llm"] = self.llm_model
        config["quick_think_llm"] = self.llm_model
        config["max_recur_limit"] = self.max_iterations
        if self.base_url:
            config["backend_url"] = self.base_url
        if self.api_key:
            config["api_key"] = self.api_key
        return config

    def _report_progress(self, agents_progress: Dict[str, str], current_agent: str, progress_pct: int, message: str = ""):
        """Report progress via callback if provided."""
        if self.progress_callback:
            self.progress_callback({
                "agents_progress": agents_progress.copy(),
                "current_agent": current_agent,
                "progress_pct": progress_pct,
                "message": message,
                "timestamp": datetime.now().isoformat(),
            })

    @property
    def graph(self) -> TradingAgentsGraph:
        """Lazy initialization of TradingAgentsGraph."""
        if self._graph is None:
            self._graph = TradingAgentsGraph(
                selected_analysts=self.analysts,
                debug=False,  # Non-interactive mode
                config=self.config,
                callbacks=None,
            )
        return self._graph

    def run(self) -> Dict[str, Any]:
        """
        Run the TradingAgents analysis workflow.
        
        Returns:
            Dict containing:
                - status: "success" or "error"
                - progress_pct: Progress percentage (0-100)
                - agents_progress: Dict mapping agent name to status
                - current_agent: Name of currently executing agent
                - final_state: Full final state from graph
                - signal: Processed trading signal
                - error: Error message if status is "error"
                - timestamp: ISO format timestamp of completion
        """
        start_time = datetime.now()
        result = {
            "status": "success",
            "progress_pct": 0,
            "agents_progress": {},
            "current_agent": "initializing",
            "final_state": None,
            "signal": None,
            "error": None,
            "timestamp": start_time.isoformat(),
        }
        agents_progress = {step_id: "not_started" for step_id, _, _ in AGENT_STEPS}

        try:
            analyst_mapping = {
                "market": "market_analyst",
                "sentiment": "sentiment_analyst",
                "social": "sentiment_analyst",
                "news": "news_analyst",
                "fundamentals": "fundamentals_analyst",
            }
            configured_analyst_steps: List[str] = []
            for analyst in self.analysts:
                mapped = analyst_mapping.get(analyst)
                if mapped and mapped not in configured_analyst_steps:
                    configured_analyst_steps.append(mapped)

            completed_analysts = set()
            completed_research = set()
            completed_risk_nodes = set()

            def emit_progress(current_agent: str, progress_pct: int, message: str) -> None:
                result["current_agent"] = current_agent
                result["progress_pct"] = progress_pct
                result["agents_progress"] = agents_progress.copy()
                self._report_progress(agents_progress, current_agent, progress_pct, message)

            # Step 1: graph_setup (0-10%)
            agents_progress["graph_setup"] = "in_progress"
            emit_progress("graph_setup", 5, "初始化分析图")

            _ = self.graph

            agents_progress["graph_setup"] = "completed"
            emit_progress("graph_setup", 10, "分析图初始化完成")

            def on_graph_progress(update: Dict[str, Any]) -> None:
                node = update.get("node")
                if not node or node in self.IGNORE_NODES:
                    return

                if node == "Research Manager":
                    if agents_progress["research_manager"] != "completed":
                        agents_progress["research_manager"] = "in_progress"
                        emit_progress("research_manager", 15, "研究经理分析中")
                    return

                # Analysts + bull/bear + trader + portfolio manager
                step_id = self.NODE_TO_STEP.get(node)
                if step_id:
                    if step_id in configured_analyst_steps:
                        if agents_progress.get(step_id) == "not_started":
                            agents_progress[step_id] = "in_progress"

                        if step_id not in completed_analysts:
                            completed_analysts.add(step_id)
                            agents_progress[step_id] = "completed"
                            analyst_total = max(1, len(configured_analyst_steps))
                            progress = 10 + int((len(completed_analysts) / analyst_total) * 45)
                            emit_progress(step_id, min(progress, 55), f"{step_id} 完成")
                        return

                    if step_id in {"bull_researcher", "bear_researcher"}:
                        if agents_progress.get(step_id) == "not_started":
                            agents_progress[step_id] = "in_progress"

                        if step_id not in completed_research:
                            completed_research.add(step_id)
                            agents_progress[step_id] = "completed"
                            progress = 60 + int((len(completed_research) / 2) * 14)
                            emit_progress(step_id, min(progress, 74), f"{step_id} 完成")
                        return

                    if step_id == "trader":
                        if agents_progress["trader"] != "completed":
                            agents_progress["trader"] = "completed"
                            emit_progress("trader", 80, "交易员阶段完成")
                        return

                    if step_id == "portfolio_manager":
                        if agents_progress["portfolio_manager"] != "completed":
                            agents_progress["portfolio_manager"] = "in_progress"
                            emit_progress("portfolio_manager", 95, "投资组合经理决策中")
                        return

                # Risk debate nodes (85-94%)
                if node in self.RISK_NODES:
                    if agents_progress["risk_manager"] == "not_started":
                        agents_progress["risk_manager"] = "in_progress"

                    if node not in completed_risk_nodes:
                        completed_risk_nodes.add(node)
                        progress = 85 + int((len(completed_risk_nodes) / len(self.RISK_NODES)) * 9)
                        if len(completed_risk_nodes) == len(self.RISK_NODES):
                            agents_progress["risk_manager"] = "completed"
                        emit_progress("risk_manager", min(progress, 94), f"风险辩论节点完成: {node}")

            # Main execution with node-level streaming updates
            final_state, signal = self.graph.propagate(
                self.symbol,
                self.date,
                progress_callback=on_graph_progress,
            )

            # Ensure final statuses for any missed stream events
            for step_id in configured_analyst_steps:
                if agents_progress.get(step_id) != "completed":
                    agents_progress[step_id] = "completed"

            if agents_progress["bull_researcher"] != "completed":
                agents_progress["bull_researcher"] = "completed"
            if agents_progress["bear_researcher"] != "completed":
                agents_progress["bear_researcher"] = "completed"
            if agents_progress["trader"] != "completed":
                agents_progress["trader"] = "completed"
            if agents_progress["risk_manager"] != "completed":
                agents_progress["risk_manager"] = "completed"
            if agents_progress["research_manager"] != "completed":
                agents_progress["research_manager"] = "completed"

            agents_progress["portfolio_manager"] = "completed"

            # Process results
            result["final_state"] = self._serialize_state(final_state)
            result["signal"] = signal
            result["progress_pct"] = 100
            result["current_agent"] = "completed"
            result["agents_progress"] = agents_progress.copy()
            result["status"] = "success"
            self._report_progress(agents_progress, "completed", 100, "分析完成")

        except Exception as e:
            # Mark the failing step before changing current_agent
            failing_step = result.get("current_agent", "")
            if isinstance(failing_step, str) and failing_step and failing_step in agents_progress and failing_step != "error":
                agents_progress[failing_step] = "failed"
            
            result["status"] = "error"
            result["error"] = str(e)
            result["current_agent"] = "error"
            result["agents_progress"] = agents_progress.copy()
            progress_pct = result.get("progress_pct", 0)
            progress_pct = progress_pct if isinstance(progress_pct, int) else 0
            self._report_progress(agents_progress, "error", progress_pct, f"分析失败: {str(e)}")

        # Update timestamp on completion
        result["timestamp"] = datetime.now().isoformat()
        return result

    def _serialize_state(self, state: Any) -> Dict[str, Any]:
        """
        Serialize the final state for JSON output.
        
        Args:
            state: The final state from graph.propagate
            
        Returns:
            Serializable dictionary representation
        """
        if state is None:
            return {}
        
        # Convert state to dict if needed
        if hasattr(state, "__dict__"):
            return self._clean_dict(vars(state))
        elif isinstance(state, dict):
            return self._clean_dict(state)
        else:
            return {"raw": str(state)}

    def _clean_dict(self, d: Dict[str, Any]) -> Dict[str, Any]:
        """
        Recursively clean a dictionary for JSON serialization.
        
        Removes non-serializable objects and converts others to serializable form.
        """
        result = {}
        for key, value in d.items():
            if isinstance(value, (str, int, float, bool, type(None))):
                result[key] = value
            elif isinstance(value, (list, tuple)):
                result[key] = [
                    self._clean_dict(v) if isinstance(v, dict) else str(v)
                    for v in value
                ]
            elif isinstance(value, dict):
                result[key] = self._clean_dict(value)
            else:
                # Convert non-serializable objects to string
                try:
                    str(value)
                    result[key] = f"<{type(value).__name__}>"
                except:
                    result[key] = "<non-serializable>"
        return result
