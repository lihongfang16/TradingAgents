"""Pydantic models for TradingAgents Web API analysis endpoints."""

from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class AnalysisStatus(str, Enum):
    """Analysis task status enumeration."""
    PENDING = "PENDING"
    RUNNING = "RUNNING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"


class StockExchange(str, Enum):
    """Stock exchange enumeration."""
    US = "US"
    CN = "CN"
    HK = "HK"


class AnalysisRequest(BaseModel):
    """Request model for single stock analysis."""
    symbol: str
    date: Optional[str] = None
    exchange: StockExchange = StockExchange.CN
    source: str = "mairui"
    analysts: List[str] = Field(default_factory=lambda: ["market", "news", "fundamentals"])
    llm_provider: Optional[str] = None
    deep_model: Optional[str] = None
    quick_model: Optional[str] = None


class AnalysisResponse(BaseModel):
    """Response model for single stock analysis."""

    task_id: str
    status: AnalysisStatus
    symbol: str
    message: str
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    completed_at: Optional[str] = None
    result: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    logs: List[Dict[str, Any]] = Field(default_factory=list)

    # Real-time progress fields (for running/pending tasks)
    agents_progress: Optional[Dict[str, str]] = None
    current_agent: Optional[str] = None
    progress_pct: Optional[int] = None
    elapsed_time: Optional[int] = None  # seconds
    remaining_time: Optional[int] = None  # seconds

    class Config:
        from_attributes = True


class BatchAnalysisRequest(BaseModel):
    """Request model for batch stock analysis."""
    symbols: List[str] = Field(min_length=1, max_length=10)
    date: Optional[str] = None
    exchange: StockExchange = StockExchange.CN
    source: str = "mairui"
    analysts: List[str] = Field(default_factory=lambda: ["market", "news", "fundamentals"])


class BatchAnalysisResponse(BaseModel):
    """Response model for batch stock analysis."""
    batch_id: str
    total: int
    completed_count: int = 0
    failed_count: int = 0
    tasks: List[AnalysisResponse]
    status: AnalysisStatus
    created_at: str
    updated_at: Optional[str] = None
    completed_at: Optional[str] = None


class AnalysisProgress(BaseModel):
    """Progress model for analysis task tracking."""
    task_id: str
    status: AnalysisStatus
    progress: float = Field(ge=0, le=100)
    current_step: str
    message: str
    timestamp: datetime
    logs: List[str] = Field(default_factory=list)
