"""
Analysis Router for TradingAgents API
"""
from typing import List, Optional, AsyncGenerator
from fastapi import APIRouter, HTTPException, Query
from sse_starlette.sse import EventSourceResponse
import asyncio
import json

from webapi.models.analysis import (
    AnalysisRequest,
    AnalysisResponse,
    BatchAnalysisRequest,
    BatchAnalysisResponse,
    AnalysisStatus,
)
from webapi.services.analysis_service import analysis_service

router = APIRouter(prefix="/api/v1/analysis", tags=["analysis"])


# ============================================================================
# Endpoints
# ============================================================================

@router.post("/", response_model=AnalysisResponse)
async def create_analysis(request: AnalysisRequest):
    """Create a new analysis task and start execution in background"""
    task = analysis_service.create_task(request)
    
    # Start analysis in background immediately
    asyncio.create_task(
        analysis_service.run_analysis(task.task_id, request)
    )
    
    return task


@router.get("/{task_id}", response_model=AnalysisResponse)
async def get_analysis(task_id: str):
    """Get analysis status by task ID"""
    result = analysis_service.get_task(task_id)
    if not result:
        raise HTTPException(status_code=404, detail="Task not found")
    return result


@router.delete("/{task_id}", status_code=204)
async def delete_analysis(task_id: str):
    """Delete an analysis task by ID"""
    deleted = analysis_service.delete_task(task_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Task not found")
    return None


@router.get("/", response_model=List[AnalysisResponse])
async def list_analyses(
    symbol: Optional[str] = Query(None, description="Filter by symbol"),
    limit: int = Query(10, ge=1, le=100, description="Maximum number of results"),
):
    """List all analyses with optional symbol filter"""
    return analysis_service.list_tasks(symbol=symbol, limit=limit)


@router.post("/batch", response_model=BatchAnalysisResponse)
async def batch_analysis(request: BatchAnalysisRequest):
    """Create and run batch analysis for multiple symbols"""
    # Use run_batch which creates tasks AND starts execution
    return await analysis_service.run_batch(request)


@router.get("/{task_id}/progress")
async def get_progress(task_id: str):
    """SSE stream for real-time progress updates with agent-level tracking"""
    async def event_generator() -> AsyncGenerator[dict, None]:
        task = analysis_service.get_task(task_id)
        if not task:
            yield {"event": "error", "data": json.dumps({"error": "Task not found"})}
            return

        # Stream real-time progress using tracked fields
        while task and task.status in (AnalysisStatus.PENDING, AnalysisStatus.RUNNING):
            progress_data = {
                "task_id": task_id,
                "status": task.status.value if hasattr(task.status, 'value') else str(task.status),
                "symbol": task.symbol,
                "agents_progress": task.agents_progress or {},
                "current_agent": task.current_agent or "",
                "progress_pct": task.progress_pct or 0,
                "message": task.message or "",
                "logs": task.logs or [],
                "done": False,
            }
            yield {
                "event": "progress",
                "data": json.dumps(progress_data),
            }
            await asyncio.sleep(2)
            task = analysis_service.get_task(task_id)

        # Final status - include full result
        final_task = analysis_service.get_task(task_id)
        final_data = {
            "task_id": task_id,
            "status": final_task.status.value if hasattr(final_task.status, 'value') else str(final_task.status),
            "symbol": final_task.symbol,
            "agents_progress": final_task.agents_progress or {},
            "current_agent": final_task.current_agent or "",
            "progress_pct": 100,
            "message": final_task.message or "",
            "logs": final_task.logs or [],
            "result": final_task.result,
            "done": True,
        }
        yield {
            "event": "complete",
            "data": json.dumps(final_data),
        }

    return EventSourceResponse(event_generator())
